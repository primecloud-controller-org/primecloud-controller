/*******************************************************************************
 *  Copyright 2014 NIFTY Corporation All Rights Reserved.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  You may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 * *****************************************************************************
 *
 *  NIFTY Cloud SDK for Java
 *  API Version: 1.19
 *  Date: 2014-10-23 17:00:00
 *
 */
package com.nifty.cloud.sdk.dashboard.model;

/**
 * ルーター情報クラス。<br />
 * このクラスはルーター情報を格納します。
 */
public class ResourceRouter {

	/** ルータータイプ */
	private String type;

	/** ルーター数 */
	private Integer count;

	/**
	 * ルータータイプを取得します。
	 *
	 * @return ルータータイプ
	 */
	public String getType() {
		return type;
	}

	/**
	 * ルータータイプを設定します。
	 *
	 * @param type ルータータイプ
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * ルータータイプを設定し、自オブジェクトを返します。
	 *
	 * @param type ルータータイプ
	 * @return 自オブジェクト
	 */
	public ResourceRouter withType(String type) {
		setType(type);
		return this;
	}

	/**
	 * ルーター数を取得します。
	 *
	 * @return ルーター数
	 */
	public Integer getCount() {
		return count;
	}

	/**
	 * ルーター数を設定します。
	 *
	 * @param count ルーター数
	 */
	public void setCount(Integer count) {
		this.count = count;
	}

	/**
	 * ルーター数を設定し、自オブジェクトを返します。
	 *
	 * @param count ルーター数
	 * @return 自オブジェクト
	 */
	public ResourceRouter withCount(Integer count) {
		setCount(count);
		return this;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("[type=");
		builder.append(type);
		builder.append(", count=");
		builder.append(count);
		builder.append("]");
		return builder.toString();
	}
}
