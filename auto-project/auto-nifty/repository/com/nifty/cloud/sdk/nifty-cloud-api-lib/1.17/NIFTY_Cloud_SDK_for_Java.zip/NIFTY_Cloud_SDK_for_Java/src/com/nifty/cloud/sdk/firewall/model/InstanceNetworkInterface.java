/*******************************************************************************
 *  Copyright 2014 NIFTY Corporation All Rights Reserved.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  You may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 * *****************************************************************************
 *
 *  NIFTY Cloud SDK for Java
 *  API Version: 1.19
 *  Date: 2014-10-23 17:00:00
 *
 */
package com.nifty.cloud.sdk.firewall.model;

/**
 *
 * ネットワークインターフェイスごとにファイアウォール適用しているサーバー情報クラス。<br />
 * このクラスはネットワークインターフェイスごとにファイアウォール適用しているサーバー情報を格納します。
 *
 */
public class InstanceNetworkInterface {

	/** サーバー名 */
	private String instanceId;

	/** サーバーユニークID */
	private String instanceUniqueId;

	/** ネットワークユニークID */
	private String networkId;

	/** デバイス番号 */
	private String deviceIndex;

	/** IPアドレス */
	private String ipAddress;


	/**
	 * サーバー名を取得します。
	 *
	 * @return サーバー名
	 */
	public String getInstanceId() {
		return instanceId;
	}

	/**
	 * サーバー名を設定します。
	 *
	 * @param instanceId サーバー名
	 */
	public void setInstanceId(String instanceId) {
		this.instanceId = instanceId;
	}

	/**
	 * サーバー名を設定し、自オブジェクトを返します。
	 *
	 * @param instanceId サーバー名
	 * @return 自オブジェクト
	 */
	public InstanceNetworkInterface withInstanceId(String instanceId) {
		setInstanceId(instanceId);
		return this;
	}

	/**
	 * サーバーユニークIDを取得します。
	 *
	 * @return サーバーユニークID
	 */
	public String getInstanceUniqueId() {
		return instanceUniqueId;
	}

	/**
	 * サーバーユニークIDを設定します。
	 *
	 * @param instanceUniqueId サーバーユニークID
	 */
	public void setInstanceUniqueId(String instanceUniqueId) {
		this.instanceUniqueId = instanceUniqueId;
	}

	/**
	 * サーバーユニークIDを設定し、自オブジェクトを返します。
	 *
	 * @param instanceUniqueId サーバーユニークID
	 * @return 自オブジェクト
	 */
	public InstanceNetworkInterface withInstanceUniqueId(String instanceUniqueId) {
		setInstanceUniqueId(instanceUniqueId);
		return this;
	}

	/**
	 * ネットワークユニークIDを取得します。
	 *
	 * @return ネットワークユニークID
	 */
	public String getNetworkId() {
		return networkId;
	}

	/**
	 * ネットワークユニークIDを設定します。
	 *
	 * @param networkId ネットワークユニークID
	 */
	public void setNetworkId(String networkId) {
		this.networkId = networkId;
	}

	/**
	 * ネットワークユニークIDを設定し、自オブジェクトを返します。
	 *
	 * @param networkId ネットワークユニークID
	 * @return 自オブジェクト
	 */
	public InstanceNetworkInterface withNetworkId(String networkId) {
		setNetworkId(networkId);
		return this;
	}

	/**
	 * デバイス番号を取得します。
	 *
	 * @return デバイス番号
	 */
	public String getDeviceIndex() {
		return deviceIndex;
	}

	/**
	 * デバイス番号を設定します。
	 *
	 * @param deviceIndex デバイス番号
	 */
	public void setDeviceIndex(String deviceIndex) {
		this.deviceIndex = deviceIndex;
	}

	/**
	 * デバイス番号を設定し、自オブジェクトを返します。
	 *
	 * @param deviceIndex デバイス番号
	 * @return 自オブジェクト
	 */
	public InstanceNetworkInterface withDeviceIndex(String deviceIndex) {
		setDeviceIndex(deviceIndex);
		return this;
	}
	/**
	 * IPアドレスを取得します。
	 *
	 * @return IPアドレス
	 */
	public String getIpAddress() {
		return ipAddress;
	}

	/**
	 * IPアドレスを設定します。
	 *
	 * @param ipAddress IPアドレス
	 */
	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	/**
	 * IPアドレスを設定し、自オブジェクトを返します。
	 *
	 * @param ipAddress IPアドレス
	 * @return 自オブジェクト
	 */
	public InstanceNetworkInterface withIpAddress(String ipAddress) {
		setIpAddress(ipAddress);
		return this;
	}


	/*
	 * (non-Javadoc)
	 *
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("[instanceId=");
		builder.append(instanceId);
		builder.append(", instanceUniqueId=");
		builder.append(instanceUniqueId);
		builder.append(", networkId=");
		builder.append(networkId);
		builder.append(", deviceIndex=");
		builder.append(deviceIndex);
		builder.append(", ipAddress=");
		builder.append(ipAddress);
		builder.append("]");
		return builder.toString();
	}
}
